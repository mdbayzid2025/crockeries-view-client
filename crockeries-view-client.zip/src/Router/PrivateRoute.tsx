import { useSelector } from 'react-redux';
import { Navigate,  useLocation } from 'react-router-dom';


const PrivateRoute = ({ children }: { children: any }) => {
 
  const selector = useSelector(state=>state?.auth?.isAuthenticated);
  const location = useLocation();

  if (!selector) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};

export default PrivateRoute;
