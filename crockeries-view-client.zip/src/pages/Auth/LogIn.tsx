import { useDispatch } from 'react-redux';
import { useShop } from '../../app/Context/ShopContext';
import { useLoginMutation } from '../../app/features/authService';
import styles from './Login.module.css';
import { Link, useNavigate } from 'react-router-dom';
import { setCredentials } from '../../app/features/authSlice';

const LogIn = () => {  
  const [login, {isLoading, isError}] = useLoginMutation();
  
  const dispatch = useDispatch();

  const navigate = useNavigate();
  
  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;

    const data: any = {
      email: (form.elements.namedItem('email') as HTMLInputElement).value,
      password: (form.elements.namedItem('password') as HTMLInputElement).value,
    };

    try {
      const result = await login(data).unwrap();
      console.log("result", result);       
      dispatch(setCredentials(result));
      navigate("/");
    } catch (err: any) {
      console.log("rrrr", err);
    }
  };

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginForm}>
        <h2 className={styles.title}>Login</h2>
        <form onSubmit={handleLogin}>
          <div className={styles.inputGroup}>
            <label htmlFor="email">Email</label>
            <input 
              type="email" 
              id="email" 
              name='email'
              placeholder="Enter your email" 
              className={styles.input}
            />
          </div>
          <div className={styles.inputGroup}>
            <label htmlFor="password">Password</label>
            <input 
              type="password" 
              id="password" 
              name='password'
              placeholder="Enter your password" 
              className={styles.input}
            />
          </div>
          <button type="submit" className={styles.button} disabled={isLoading}>
            {isLoading ? "Logging In..." : "Login"}
          </button>
          {isError && <p className={styles.errorText}>Login failed. Please check your credentials.</p>}
        </form>
        <p className={styles.text}>
          Don't have an account? <Link to="/signup" className={styles.link}>Sign up</Link>
        </p>
      </div>
    </div>
  );
};

export default LogIn;
